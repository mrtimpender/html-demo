
    <footer>
      <!-- Include the navigation -->
    	<?php include 'nav.php'; ?>

    	<p>Copyright 2015 - Your Name Here</p>
    </footer>

  </body>
</html>

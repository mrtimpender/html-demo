
<!-- Sidebar Area & Widgets-->
<div class="column one-third sidebar">

	<!-- Begin widget -->
	<div class="widget">
		<h3>Widget Title</h3>
		<p>Haircut engaged something Dibble Dibble Dibble Dibble nonsensical alone sadly prickle-ly playthings Wickersham Brothers guaranteed murmur.</p>
	</div>
	<!-- End Widget -->


	<!-- Begin widget -->
	<div class="widget">
		<h3>Widget Title</h3>
		<p>Haircut engaged something Dibble Dibble Dibble Dibble nonsensical alone sadly prickle-ly playthings Wickersham Brothers guaranteed murmur.</p>
	</div>
	<!-- End Widget -->


	<!-- Begin widget -->
	<div class="widget">
		<h3>Widget Title</h3>
		<p>Haircut engaged something Dibble Dibble Dibble Dibble nonsensical alone sadly prickle-ly playthings Wickersham Brothers guaranteed murmur.</p>
	</div>
	<!-- End Widget -->

</div>
